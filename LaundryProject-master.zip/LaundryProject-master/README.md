# LaundryProject
Desktop Apps for Laundry Services

Screenshoot
![image](https://user-images.githubusercontent.com/19624267/34572432-f2ca9948-f1a3-11e7-9c6e-4cdb7b32f6ff.png)
![image](https://user-images.githubusercontent.com/19624267/34572460-098c5ca2-f1a4-11e7-95c8-9c36f07e7acb.png)
